#!/usr/bin/python
# coding=utf-8
import os
import sys
import time
import threading
import socket
import robotcontrol
import publicdef
from math import pi
import math as m
import Camera_threadX
#sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

def print_time( threadName, delay):
# 创建 socket 对象
    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
# 获取本地主机名
    host = socket.gethostname()

    port = 5017
# 绑定端口号
    serversocket.bind((host, port))

# 设置最大连接数，超过后排队
    serversocket.listen(5)
    while True:
# 建立客户端连接
    	clientsocket,addr = serversocket.accept()      

    	print("连接地址: %s" % str(addr))
    
    	msg='ROBOT！'+ "\r\n"
    	clientsocket.send(msg.encode('utf-8'))
    	clientsocket.close()

    return
def Laser_V_to_Lenth():
    #while True:
        ioname = robotcontrol.RobotToolIoName.tool_ai_0
        Vt = robot.get_tool_io_status(ioname)
        #print("Tool_01_00 status is {0}".format(aaab))
        VT = float(Vt)
        #S = 60.06*VT+47
        S = 59.61*VT+49.33
        return S

def Laser_Pi_to_yaw(S1,S2):
    #while True:        
        delT = S2-S1
        S = m.atan(delT/100)
        return S

def TCP_Transfer(x,y,z,position): #add height '200'
    if (position == 0):
        return -z+200  #height varial
    elif (position == 1):
        return y
    elif (position == 2):
        return x-580
    else :
        return 0
def Move_Target_x_y_z(x,y,z):
    # 获取当前位置
    global robot
    current_pos = robot.get_current_waypoint()
    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
    current_pos['pos'][0] = x / 1000
    current_pos['pos'][1] = y / 1000
    current_pos['pos'][2] = z / 1000

    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
    if (ik_result != None):
        return robot.move_line(ik_result['joint'])
    else:
        robotcontrol.logger.error("inverse_kin return none.")
        return None

#*******************************MAIN************************************
#机械臂IP
RobotIp = "192.168.1.112"
#机械臂端口
RobotPort = 8899

process_flag = 0
position_flag = ''
down_depth = 224
SleepTime = 2
    

if __name__ == '__main__':
    #初始化logger
    robotcontrol.logger_init()
    # 启动测试
    robotcontrol.logger.info("{0} move_offset_Rx test beginning...".format(robotcontrol.Auboi5Robot.get_local_time()))

    # 系统初始化tool_ai_0
    robotcontrol.Auboi5Robot.initialize()

    # 创建机械臂控制类tool_ai_0
    robot = robotcontrol.Auboi5Robot()

    # 创建上下文
    handle = robot.create_context()

    # 打印上下文
    robotcontrol.logger.info("robot.rshd={0}".format(handle))

    try:
        # 链接服务器       
        result = robot.connect(RobotIp, RobotPort)
        if result != robotcontrol.RobotErrorType.RobotError_SUCC:
                robotcontrol.logger.error("connect server{0}:{1} failed.".format(robotcontrol.RobotIp, robotcontrol.port))
                
        else:            
            # 初始化全局配置文件
            robot.init_profile()
            robot.set_collision_class(robotcontrol.CollisionLevel) 
            #intial position
            init_jiont_radian_rad = [i / 180.0 * robotcontrol.pi for i in publicdef.paral_ground_radian]
            robot.move_joint(init_jiont_radian_rad)
            obj = Camera_threadX.CameraTask.instance()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
           
            
            #print(obj.take_picture_001())
            #time.sleep(5)
            #print(obj.take_picture_002())
            # 获取本地主机名
            host = socket.gethostname() 
            # 设置端口号
            #port = 9999   
            # 连接服务，指定主机和端口
            #s.connect((host, port)) 
            s.connect(('192.168.1.90', 5016))       
            while True:
                #time.sleep(1)
                # receive main control and send data
                recv_data = s.recv(1024)
                #GLOBLE.GLOBAL_VAR = recv_data.decode('utf-8')
#*************************************
                print (recv_data.decode('utf-8'))
                #print("返回的消息为:",recv_data.decode('gbk')) 
                str1=recv_data.decode('gbk')
                print(str1)
                a=str1.split('|')
                print(len(a))
                a0=a[0].split(":")
                task_enable=int(a0[1])
                print('task_enable',task_enable)
                a1=a[1].split(':')
                task_type=int(a1[1])
                print('task_type',task_type)
                a2=a[2].split(':')
                lift_height=float(a2[1])
                print('lift_height',lift_height)
                a3=a[3].split(':')
                agv_current_x=float(a3[1])
                print('agv_current_x',agv_current_x)
                a4=a[4].split(':')
                agv_current_y=float(a4[1])
                print('agv_current_y',agv_current_y)
                a5=a[5].split(':')
                agv_current_z=float(a5[1])
                print('agv_current_z',agv_current_z)
                a6=a[6].split(':')
                agv_current_yaw=float(a6[1])
                print('agv_current_yaw',agv_current_yaw)
                a7=a[7].split(':')
                start_point_x=float(a7[1])
                print('start_point_x',start_point_x)
                a8=a[8].split(':')
                start_point_y=float(a8[1])
                print('start_point_y',start_point_y)
                a9=a[9].split(':')
                start_point_z=float(a9[1])
                print('start_point_z',start_point_z)
                a10=a[10].split(':')
                end_point_x=float(a10[1])
                print('end_point_x',end_point_x)
                a11=a[11].split(':')
                end_point_y=float(a11[1])
                print('end_point_y',end_point_y)
                a12=a[12].split(':')
                end_point_z=float(a12[1])
                print('end_point_z',end_point_z)
                a13=a[13].split(':')
                line_type=int(a13[1])
                print('line_type',line_type)
                a14=a[14].split(':')
                line_barrier=int(a14[1])
                print('line_barrier',line_barrier)
                a15=a[15].split(':')
                camera_string_msg=a15[1]  

                start_point_x0 = TCP_Transfer(start_point_x,start_point_y,start_point_z,0)
                start_point_y0 = TCP_Transfer(start_point_x,start_point_y,start_point_z,1)
                start_point_z0 = TCP_Transfer(start_point_x,start_point_y,start_point_z,2)

                end_point_x0 = TCP_Transfer(end_point_x,end_point_y,end_point_z,0)
                end_point_y0 = TCP_Transfer(end_point_x,end_point_y,end_point_z,1)
                end_point_z0 = TCP_Transfer(end_point_x,end_point_y,end_point_z,2)

                SS = Laser_V_to_Lenth()
                print(SS)
                
                #time.sleep(1)
                #strValue = raw_input("please input offset_Rx value(°):")  
                
                if((camera_string_msg == 'logic_cmd')and(process_flag == 0)and(task_enable == 1)) : 
                    time.sleep(SleepTime)
                # 获取当前位置
                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))  
                    # 沿X轴运动x毫米                       
                    current_pos['pos'][0] = current_pos['pos'][0]
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.set_end_max_line_acc(0.5)
                        robot.set_end_max_line_velc(0.4)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)
                    #调节起点拍照偏移
                    current_pos = robot.get_current_waypoint()
                    current_pos['pos'][0] = current_pos['pos'][0]-100.0/1000
                    #current_pos['pos'][0] = start_point_x0/1000 + (300/1000)
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S2 = Laser_V_to_Lenth()
                    print(S2)
                    TT = Laser_Pi_to_yaw(S1,S2)
                    print(TT)
                    
                    #调整相机角度
                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
                    #四元素转欧拉角
                    ppp = robot.quaternion_to_rpy(current_pos['ori'])
                    #叠加欧拉角
                    radValue = TT
                    ppp[1] = ppp[1] + TT
                    #欧拉角转四元素
                    ori = robot.rpy_to_quaternion(ppp)
                    #逆解
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], ori)
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_joint(ik_result['joint'])
                    else:
                        robotcontrol.logger.info("inverse_kin return none.")

                    #回到起点位置
                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
                    current_pos['pos'][0] = current_pos['pos'][0]+100.0/1000
                    #current_pos['pos'][0] = start_point_x0/1000 + (300/1000)
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.set_end_max_line_acc(0.5)
                        robot.set_end_max_line_velc(0.4)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")

                    S2 = Laser_V_to_Lenth()
                    distanceZ =S2 - 310.0

                    #回到起点位置拍照
                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
                    current_pos['pos'][2] = current_pos['pos'][2]+distanceZ/1000
                    #current_pos['pos'][0] = start_point_x0/1000 + (300/1000)
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S2 = Laser_V_to_Lenth()
                    print(S2)
                    # photo begin START......... 
                    #PhotoStr1 = obj.take_picture_001()
                    #Photo_A =PhotoStr1.split(';')
                    #camera_x1 = float(Photo_A[1])
                    #print(camera_x1)
                    #camera_y1 = float(Photo_A[2])
                    #print(camera_y1)
                    #abcd = raw_input("start photo:")
                    print('Photo!')
                    time.sleep(1)
                    
                    #发送流程进度以及拍照给主控，主控对拍照不处理
                    send1='progress:'
                    progress=0
                    send2='percent_complete:'
                    percent_complete=0.0
                    send3='status:'
                    status=1
                    send4='camera_string_cmd:'
                    camera_string_cmd='001'         
                    send=send1+str(progress)+'|'+send2+str(percent_complete)+'|'+send3+str(status)+'|'+send4+camera_string_cmd+'|'
                    time.sleep(1)
                    if (task_enable == 1):
                        print('001 time : 001')  
                        s.send(send.encode()) 
                    if (task_enable == 4):
                        print('Finish the Control Process~~~~~!!')
                        #abcd = raw_input("task Finished:")

                if((process_flag == 0)and(task_enable == 1)):
                    #.....................   
                    # 沿X轴运动x毫米 
                    current_pos = robot.get_current_waypoint()                      
                    current_pos['pos'][0] = current_pos['pos'][0]-600.0/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)

                    current_pos = robot.get_current_waypoint()
                    current_pos['pos'][0] = current_pos['pos'][0]+100.0/1000
                    #current_pos['pos'][0] = start_point_x0/1000 + (300/1000)
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")

                    S2 = Laser_V_to_Lenth()
                    print(S2)
                    TT = Laser_Pi_to_yaw(S1,S2)
                    print(TT)

                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
                    #四元素转欧拉角
                    ppp = robot.quaternion_to_rpy(current_pos['ori'])
                    #叠加欧拉角
                    radValue = TT
                    ppp[1] = ppp[1] + TT
                    #欧拉角转四元素
                    ori = robot.rpy_to_quaternion(ppp)
                    #逆解
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], ori)
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_joint(ik_result['joint'])
                    else:
                        robotcontrol.logger.info("inverse_kin return none.")

                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
                    current_pos['pos'][0] = current_pos['pos'][0]-100.0/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S2 = Laser_V_to_Lenth()
                    distanceZ =S2 - 310.0

                    current_pos = robot.get_current_waypoint()          
                    robotcontrol.logger.info("current_pos:{0}".format(current_pos))
                    current_pos['pos'][2] = current_pos['pos'][2]+distanceZ/1000
                    #current_pos['pos'][0] = start_point_x0/1000 + (300/1000)
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S2 = Laser_V_to_Lenth()
                    print(S2)
                    # photo begin END......... 
                    #PhotoStr1 = obj.take_picture_002()
                    #Photo_A =PhotoStr1.split(';')
                    #camera_x2 = float(Photo_A[1])
                    #print(camera_x2)
                    #camera_y2 = float(Photo_A[2])
                    #print(camera_y2)
                    #abcd = raw_input("end photo:")
                    print('Photo!')
                    time.sleep(1)
                    #发送流程进度50以及拍照主控，主控对拍照不处理
                    send1='progress:'
                    progress=50
                    send2='percent_complete:'
                    percent_complete=50.0
                    send3='status:'
                    status=1
                    send4='camera_string_cmd:'
                    camera_string_cmd='002' 
                    print('002 time : 002')                           
                    send=send1+str(progress)+'|'+send2+str(percent_complete)+'|'+send3+str(status)+'|'+send4+camera_string_cmd+'|'
                    time.sleep(1)
                    s.send(send.encode()) 
                    
                    #.....................
                    #return to START UP   
                    current_pos = robot.get_current_waypoint()  
                    #abcd = raw_input("enter Camera_xy1:") 
                    camera_y1 = 0
                    camera_x1 = 0                   
                    current_pos['pos'][0] = current_pos['pos'][0]+(600.0+camera_y1)/1000
                    current_pos['pos'][1] = current_pos['pos'][1]+camera_x1/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)

                                        
                    #DOWN TO GROUND 100mm TO THE start point                    
                    current_pos = robot.get_current_waypoint()                      
                    current_pos['pos'][2] = current_pos['pos'][2]+(S1-100.0)/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)
                    #发送流程进度100给主控，主控准备填缝
                    send1='progress:'
                    progress=100
                    send2='percent_complete:'
                    percent_complete=100.0
                    send3='status:'
                    status=1
                    send4='camera_string_cmd:'
                    camera_string_cmd=''           
                    send=send1+str(progress)+'|'+send2+str(percent_complete)+'|'+send3+str(status)+'|'+send4+camera_string_cmd+'|'
                    s.send(send.encode())
                    process_flag = 1
                                 
                    #开始填缝
                   #DOWN TO GROUND 100mm TO THE end point 
                if((process_flag == 1) and (task_enable == 2)) : 
                    
                    #abcd = raw_input("enter Camera_end:")  
                                    
                    current_pos = robot.get_current_waypoint()  
                    camera_y2 = 0 
                    camera_x2 = 0                   
                    current_pos['pos'][0] = current_pos['pos'][0]+(-300.0+camera_y2)/1000
                    current_pos['pos'][1] = current_pos['pos'][1]+camera_x2/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        #robot.set_end_max_line_acc(0.1)
                        robot.set_end_max_line_velc(0.1)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)


                    current_pos = robot.get_current_waypoint()                      
                    current_pos['pos'][2] = current_pos['pos'][2]+(S1-100.0)/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.set_end_max_line_acc(0.1)
                        robot.set_end_max_line_velc(0.1)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)

                    current_pos['pos'][0] = current_pos['pos'][0]+(-300.0+camera_y2)/1000
                    current_pos['pos'][1] = current_pos['pos'][1]+camera_x2/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        #robot.set_end_max_line_acc(0.1)
                        robot.set_end_max_line_velc(0.1)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)

                    current_pos = robot.get_current_waypoint()  
                    camera_y2 = 0 
                    camera_x2 = 0                   
                    #current_pos['pos'][0] = current_pos['pos'][0]+(-300.0+camera_y2)/1000
                    current_pos['pos'][1] = current_pos['pos'][1]+(-150.0)/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        #robot.set_end_max_line_acc(0.1)
                        robot.set_end_max_line_velc(0.1)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1) 

                    current_pos = robot.get_current_waypoint()                      
                    current_pos['pos'][2] = current_pos['pos'][2]+(S1-100.0)/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        robot.set_end_max_line_acc(0.1)
                        robot.set_end_max_line_velc(0.1)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1)

                    current_pos = robot.get_current_waypoint()  
                    camera_y2 = 0 
                    camera_x2 = 0                   
                    #current_pos['pos'][0] = current_pos['pos'][0]+(-300.0+camera_y2)/1000
                    current_pos['pos'][1] = current_pos['pos'][1]+(-150.0)/1000
                    ik_result = robot.inverse_kin(current_pos['joint'], current_pos['pos'], current_pos['ori'])
                    robotcontrol.logger.info("ik_result:{0}.".format(ik_result))
                    if (ik_result != None):
                        #robot.set_end_max_line_acc(0.1)
                        robot.set_end_max_line_velc(0.1)
                        robot.move_line(ik_result['joint'])
                    else:
                        robotcontrol.logger.error("inverse_kin return none.")
                    S1 = Laser_V_to_Lenth()            
                    print(S1) 
                    #填缝完成发送进度
                    send1='progress:'
                    progress=100
                    send2='percent_complete:'
                    percent_complete=100.0
                    send3='status:'
                    status=2
                    send4='camera_string_cmd:'
                    camera_string_cmd=''           
                    send=send1+str(progress)+'|'+send2+str(percent_complete)+'|'+send3+str(status)+'|'+send4+camera_string_cmd+'|'
                    s.send(send.encode()) 
                    process_flag = 2
                    
                if((process_flag == 2) and (task_enable == 2)) : 
                    #intial position
                    init_jiont_radian_rad = [i / 180.0 * robotcontrol.pi for i in publicdef.paral_ground_radian]
                    #robot.set_end_max_line_acc(0.5)
                    #robot.set_end_max_line_velc(0.5)
                    robot.move_joint(init_jiont_radian_rad)
                    #发送回到起点姿态进度给主控，完成一轮填缝任务
                    send1='progress:'
                    progress=100
                    send2='percent_complete:'
                    percent_complete=100.0
                    send3='status:'
                    status=3
                    send4='camera_string_cmd:'
                    camera_string_cmd=''           
                    send=send1+str(progress)+'|'+send2+str(percent_complete)+'|'+send3+str(status)+'|'+send4+camera_string_cmd+'|'
                    s.send(send.encode()) 
                    process_flag = 0
         
    except robotcontrol.RobotError as e:
        robotcontrol.logger.error("robot Event:{0}".format(e))
    finally:
        # 断开服务器链接RobotPort
        if robot.connected:
                # 断开机械臂链接
                robot.disconnect()
        # 释放库资源
        robotcontrol.Auboi5Robot.uninitialize()
        robotcontrol.logger.info("{0} test completed.".format(robotcontrol.Auboi5Robot.get_local_time()))


